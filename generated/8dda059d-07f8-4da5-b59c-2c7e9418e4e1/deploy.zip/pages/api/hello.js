export default function handler(req, res) {
  res.status(200).json({ name: 'Brief2Blok API' })
}