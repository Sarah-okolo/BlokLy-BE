module.exports = {
  reactStrictMode: true,
}